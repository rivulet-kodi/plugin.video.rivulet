# SPDX-FileCopyrightText: 2026 M0Rf30
# SPDX-License-Identifier: MIT

"""rivulet-engine client (pure Python, no Kodi imports).

Turns Stream protocol objects (stremio-protocol-spec.md #3, stremio-core
src/types/resource/stream.rs StreamSource) into URLs playable against a
local rivulet-engine instance, mirroring stremio-core's Stream::convert
(stream.rs:234-604) for every source kind that endpoint recognizes:

- Torrent (infoHash/fileIdx/announce-or-sources) -> GET {server}/{infoHash}/{fileIdx}
  with repeated `tr=` tracker query params. Confirmed against server-go's
  internal/api/api.go (`trackers := q["tr"]`) and docs/swagger.yaml's
  `/{infoHash}/{fileIdx}` streaming endpoint. `infoHash` accepts either
  the 40-char hex `hex::encode` form or a magnet's 32-char RFC 4648
  Base32 form (upstream e200aff9); trackers are percent-decoded,
  reduced to bare announce URLs (a `tracker:` wrapper is stripped and
  `dht:` entries dropped) and deduped before becoming `tr=` params
  (`normalize_peer_search_sources`, streaming_server/request.rs:86-98,
  upstream 87b65391/bc5aa9d8) - see
  `normalize_info_hash`/`normalize_trackers` below. The same trackers
  also ride on the `/{infoHash}/create` warm-up (as a stremio-core style
  `peerSearch` POST - see `create_engine`) and on the pre-buffer front
  reads (as `tr=`), so the engine knows the stream's own trackers from
  its very first request instead of only once Kodi opens the final URL.
- YouTube (ytId) -> GET {server}/yt/{ytId} (swagger `/yt/{id}`).
- Plain url: validated against `_DIRECT_URL_SCHEMES` and returned
  unchanged when allowed (see that constant for the exact scheme
  list); a `magnet:` url is parsed for `xt=urn:btih:` + `tr=` params
  and converted the same way as a Torrent source, since a bare magnet
  link needs the server to fetch it; a bare `ftp://`/`ftps://` url is
  proxied through `/ftp/{filename}` (see `_ftp_create_url` below).
  Anything else (a Kodi control/local scheme like `plugin:`/`script:`/
  `special:`/`file:`, an empty/relative/malformed url, or any scheme
  outside the allowlist) raises `UnsupportedStreamError` - a Stream
  dict is untrusted addon data, so its `url` field must be validated
  before it ever reaches Kodi's player.
- Archive sources (rar/zip/7zip/tgz/tar) and Nzb -> GET
  {server}/{kind}/create/{key}?lz=<payload>, where `key` is the sha256
  (hex, first 32 chars) of the compact JSON body so an identical
  re-request reuses the server's live session (rivulet-engine
  v0.23.0, ~1 h; local archives rechecked by size+mtime), and a nested ftp(s) member url ->
  GET {server}/ftp/{filename}?lz=<payload>, where <payload> is
  `lib.stremio.lzstring.compress_to_encoded_uri_component()` of the
  request JSON body - mirroring stream.rs's Rar/Zip/Zip7/Tgz/Tar/Nzb
  `StreamSource::convert()` branches (stream.rs:240-437) and
  `ftp_url_handler` (stream.rs:186-214). See `_archive_create_url`,
  `_resolve_nzb_stream` and `_ftp_create_url` below.
- `externalUrl`/`playerFrameUrl` (`StreamSource::External`/`PlayerFrame`,
  stream.rs:818-835) raise `UnsupportedStreamError`: stremio-core
  recognizes these, but neither is a URL Kodi's player can ever open (an
  external app deep-link and an embeddable iframe player, respectively)
  - distinct from returning None ("we don't understand this stream" /
  "missing data needed to build one"), so callers can show an honest,
  specific message instead of the generic failure one.

iter_front() is the client's readiness probe for torrents: it streams the
FIRST bytes of the file (offset 0, Range GET) rather than trusting
aggregate download progress. Verified live against rivulet-engine
v0.8.5: a torrent's *aggregate* per-file stats (`streamProgress` x
`streamLen` from `/{infoHash}/{fileIdx}/stats.json`) can
report megabytes downloaded while the front of the file - where ffmpeg's
container-header probe reads from - is still completely unavailable
(pieces download out of order), causing Kodi's player to fail with
CURLE_PARTIAL_FILE / "error probing input format" even though pre-buffer
"succeeded" by the old aggregate-byte-count metric. A front Range read
both DRIVES the server's front-prioritization (NewReader ->
primeBoundary/warmMoov, internal/engine/engine.go:766-813) and PROVES
playback will actually start cleanly.

resolve_stream() is a pure URL builder - it does not check whether the
server is actually reachable. Callers should call is_available() first
(e.g. to show string 30031 "Streaming server unavailable") before relying
on a torrent/YouTube/magnet/archive/nzb/ftp URL it returns.
"""
import base64
import binascii
import hashlib
import json
import re
from urllib.parse import parse_qs, quote, unquote, urlencode, urlparse

from lib.stremio import addons as _addons
from lib.stremio.addons import _request_error_category, safe_url_for_log

#: `requests` costs ~35ms and ~200 transitive modules to import - resolved
#: lazily on first `ServerClient.__init__()` call via `_ensure_requests()`
#: rather than at module import time, so importing this module's pure
#: helpers (normalize_info_hash, normalize_trackers, guess_file_idx, ...)
#: never pays that cost. `_UNSET` marks "not resolved yet" (distinct from a
#: real `None`, the cached "package not installed" outcome) so a test
#: directly assigning `requests = None` is honoured without triggering a
#: redundant re-import.
_UNSET = _addons._UNSET
requests = _UNSET


def _ensure_requests():
    """Bind this module's `requests` global on first call, from the copy
    `lib.stremio.addons._ensure_requests()` resolves (one import, one
    "not installed" outcome, for the whole protocol layer). It stays a
    module global rather than a call per use because every method below
    tests `requests is None` and catches `requests.RequestException`."""
    global requests
    if requests is _UNSET:
        requests = _addons._ensure_requests()
    return requests


#: `compress_to_encoded_uri_component` (a 334-line pure-Python codec) is
#: imported lazily inside `_lz_query_url()` below, the single call site
#: shared by `_ftp_create_url`/`_archive_create_url`/`_resolve_nzb_stream` -
#: it is only ever needed on the rare archive/nzb/ftp resolve path, never
#: for a torrent/magnet/direct-url/YouTube stream.

#: Same percent-encoding safe set stremio-core uses for the /yt/{id} path
#: segment (URI_COMPONENT_ENCODE_SET, constants.rs).
_YT_SAFE_CHARS = "-_.!~*'()"

#: fileIdx sentinel meaning "not specified" - tells rivulet-engine to
#: auto-select the largest file in the torrent (stream.rs:
#: `file_idx.map_or_else(|| "-1".to_string(), ...)`). NOT 0.
UNKNOWN_FILE_IDX = -1

#: File extensions rivulet-engine's GuessFileIdx treats as playable
#: (internal/engine/engine.go `videoExts`); `guess_file_idx()` mirrors it.
_VIDEO_EXTENSIONS = (
    '.mkv', '.mp4', '.avi', '.mov', '.m4v', '.webm', '.flv', '.wmv', '.mpg', '.mpeg', '.ts', '.m2ts',
)

#: Lengths, in characters, of the two info-hash encodings a magnet or a
#: Stream object's `infoHash` may carry - `normalize_info_hash()` accepts
#: only these two lengths.
_HEX_HASH_LENGTH = 40
_BASE32_HASH_LENGTH = 32
#: A BitTorrent info hash is always a 160-bit SHA-1 digest.
_INFO_HASH_BYTES = 20

#: Archive `StreamSource` variants stremio-core recognizes (stream.rs:
#: 738-792), keyed by the Stream protocol field carrying their URL list,
#: mapped to the `/{kind}/create` path segment rivulet-engine exposes
#: for each.
_ARCHIVE_KIND_BY_KEY = {
    'rarUrls': 'rar',
    'zipUrls': 'zip',
    '7zipUrls': '7zip',
    'tgzUrls': 'tgz',
    'tarUrls': 'tar',
}

#: Schemes `resolve_stream()` accepts for a Stream's own `url` field once
#: `magnet:`/`ftp(s):` have been special-cased into a different URL
#: (see the module docstring) - the current, intended network-media
#: families Kodi's player can open directly. `smb`/`nfs` are
#: deliberately excluded even though Kodi's VFS can mount them: a
#: Stremio Stream is untrusted addon data, and a LAN file share is a
#: fundamentally different trust boundary than a network video stream -
#: an addon must never be able to steer Kodi's player at an arbitrary
#: SMB/NFS path on the user's network. `_validate_direct_url()` rejects
#: everything else too, including Kodi control/local schemes (`plugin`,
#: `script`, `special`, `file`, ...) a rogue addon could otherwise
#: smuggle into an untrusted Stream dict.
_DIRECT_URL_SCHEMES = frozenset({
    'http', 'https',
    'ftp', 'ftps',
    'rtmp', 'rtmps',
    'rtsp',
    'rtp',
    'udp',
})

#: honey: caps rarUrls/zipUrls/.../nzbUrls entry counts before
#: `_lz_query_url()` runs lzstring's per-char Python compressor over the
#: JSON body on the UI thread - an addon returning a pathological
#: thousands-of-mirrors list would otherwise freeze Kodi's UI building a
#: `/…/create` request nothing sane needs more than a handful of mirrors
#: for.
_MAX_ARCHIVE_URL_ENTRIES = 32


#: Query parameters whose values are masked by `redact_url()`.
_SENSITIVE_QUERY_KEYS = frozenset({
    'lz', 'token', 'access_token', 'api_key', 'apikey', 'key', 'password', 'pass', 'passwd',
    'secret', 'auth', 'authorization', 'signature', 'sig',
    # Private-tracker announce URLs carry the account passkey, in a `tr=`
    # value or a `passkey=` parameter.
    'tr', 'passkey',
})

#: Stream ids `/yt/{id}` is built for (YouTube ids are 11 chars; some slack).
_YT_ID_RE = re.compile(r'^[A-Za-z0-9_-]{1,20}$')


def redact_url(url):
    """`url` with userinfo (`user:pass@`) and sensitive query values
    (`lz` payloads, tokens, passwords...) masked, safe for logging.
    Never raises; unparseable input yields `<invalid-url>`."""
    try:
        text = str(url)
        parsed = urlparse(text)
        netloc = parsed.netloc
        if '@' in netloc:
            netloc = '***@' + netloc.rsplit('@', 1)[1]
        query = parsed.query
        if query:
            parts = []
            for piece in query.split('&'):
                name, sep, _value = piece.partition('=')
                if sep and unquote(name).lower() in _SENSITIVE_QUERY_KEYS:
                    piece = name + '=***'
                parts.append(piece)
            query = '&'.join(parts)
        return parsed._replace(netloc=netloc, query=query, params='' if not parsed.params else '***').geturl()
    except Exception:  # noqa: BLE001 - logging helper must never raise
        return '<invalid-url>'


def _is_heartbeat_body(body):
    return isinstance(body, dict) and body.get('success') is True


def _is_settings_body(body):
    return isinstance(body, dict) and isinstance(body.get('values'), dict)


def _redact_error_url(base_url, url):
    """`url` with its `base_url` prefix (the free-text server_url setting,
    which may carry `user:pass@` userinfo) replaced by
    `safe_url_for_log(base_url)`, and sensitive query values masked - so a
    `ServerError` message never echoes credentials.

    The query string is dropped outright: it holds `tr=` announce URLs
    (private-tracker passkeys can sit in their path, which masking by key
    name cannot catch) and `lz` payloads, and an error message has no use
    for either."""
    safe_base = safe_url_for_log(base_url)
    url = url.partition('?')[0]
    suffix = url[len(base_url):] if url.startswith(base_url) else url
    if suffix.startswith('/') or suffix.startswith('?') or not suffix:
        return redact_url(safe_base + suffix)
    return redact_url(suffix)


def normalize_info_hash(value):
    """Normalize a torrent info hash to the 40-char lowercase hex string
    rivulet-engine's URL paths require (`hex::encode`, stream.rs:545).

    Accepts the 40-char hex form OR a magnet's 32-char RFC 4648 Base32
    form (BEP 0003 permits either encoding for a magnet's `xt=urn:btih:`
    value; stremio-core normalizes on ingest, upstream commit e200aff9,
    2025-11-18: "support base32 encoded info hash for magnet links").
    Anything else - wrong length, or characters outside the relevant
    alphabet - can't be turned into a hash the server understands, so
    this returns None rather than handing garbage to a URL builder.
    """
    if not isinstance(value, str):
        return None
    candidate = value.strip()
    if len(candidate) == _HEX_HASH_LENGTH:
        try:
            binascii.unhexlify(candidate)
        except (binascii.Error, ValueError):
            return None
        return candidate.lower()
    if len(candidate) == _BASE32_HASH_LENGTH:
        try:
            raw = base64.b32decode(candidate.upper())
        except (binascii.Error, ValueError):
            return None
        if len(raw) != _INFO_HASH_BYTES:
            return None
        return binascii.hexlify(raw).decode('ascii')
    return None


def normalize_trackers(values):
    """Reduce a raw `announce`/`sources` tracker list to bare, deduped
    announce URLs ready to become `tr=` query params (mirrors
    `normalize_peer_search_sources`, stremio-core src/types/
    streaming_server/request.rs:86-98, upstream 87b65391/bc5aa9d8):

    - percent-decoded, since some addons ship a tracker/source entry that
      is itself percent-encoded (e.g. a `tracker:<percent-encoded-url>`
      wrapper);
    - a `tracker:` wrapper is stripped. Torrentio/AIOStreams-style
      `sources` lists wrap every announce URL that way, and stremio-core
      forwards them verbatim, but rivulet-engine <= v0.20.0 treated a
      `tracker:udp://...` value as a host-less URL and dropped it (verified
      live: `tr=tracker:udp://x` never reached the engine's announce
      list, `tr=udp://x` did), so the wrapped form silently carried no
      trackers at all;
    - `dht:<infohash>` entries are dropped: they carry no announce URL
      (the server's DHT finds peers on its own);
    - empty entries are dropped and duplicates removed, order preserved.
    """
    seen = set()
    normalized = []
    for value in values if isinstance(values, list) else ():
        if not isinstance(value, str):
            continue
        decoded = unquote(value).strip()
        if decoded.startswith('dht:'):
            continue
        if decoded.startswith('tracker:'):
            decoded = decoded[len('tracker:'):].strip()
        if not decoded or decoded in seen:
            continue
        seen.add(decoded)
        normalized.append(decoded)
    return normalized


def stream_trackers(stream):
    """The raw tracker list of a torrent Stream object: `announce`, falling
    back to `sources` when absent - stremio-core deserializes torrent
    trackers with `#[serde(alias = "sources")]` (stream.rs:812), and
    Torrentio/AIOStreams-style addons ship them under `sources` (e.g.
    "tracker:udp://host:port/announce", "dht:<hash>"). Feed the result to
    `normalize_trackers()` (every URL builder here does) before use.
    """
    if not isinstance(stream, dict):
        return []
    trackers = stream.get('announce') or stream.get('sources')
    return trackers if isinstance(trackers, list) else []


def _close_quietly(resp):
    """Close `resp` if there is one; closing must never mask the real outcome."""
    if resp is None:
        return
    try:
        resp.close()
    except Exception:  # noqa: BLE001
        pass


def _clean_file_idx(value):
    """`value` if it is a real file index (an int, bool excluded, >= -1),
    else UNKNOWN_FILE_IDX. `fileIdx` is untrusted addon data interpolated
    into the engine URL path: a string like `0/../../settings?` would
    otherwise be normalized by the player into a request for any engine
    endpoint."""
    if isinstance(value, int) and not isinstance(value, bool) and value >= UNKNOWN_FILE_IDX:
        return value
    return UNKNOWN_FILE_IDX


def _is_ftp_url(value):
    """True if `value` is a string with an `ftp://`/`ftps://` scheme -
    stremio-core proxies both the same way (`Stream::ftp_url_handler`
    matches scheme "ftp" or "ftps", stream.rs:187-188).
    """
    return isinstance(value, str) and (value.startswith('ftp://') or value.startswith('ftps://'))


def _ftp_filename(url):
    """Last non-empty path segment of `url`, or None if it has none -
    mirrors `Stream::ftp_filename` (stream.rs:169-176), which upstream
    uses as the `/ftp/{filename}` path segment. Upstream raises an
    `EnvError` when there's no path segment to use; this addon just
    treats that url as unusable.
    """
    try:
        path = urlparse(url).path
    except ValueError:
        return None
    segments = [segment for segment in path.split('/') if segment]
    return segments[-1] if segments else None


def _validate_direct_url(url):
    """Return `url` unchanged if it is an absolute network-media URL
    whose scheme is in `_DIRECT_URL_SCHEMES`, else raise
    `UnsupportedStreamError`.

    Never rewrites `url` - only `_ftp_create_url()`/`_magnet_to_torrent_url()`
    (checked before this is ever called, see `resolve_stream()`) turn a
    Stream's own `url` field into a different URL. Rejects: non-strings,
    empty strings, relative urls (no scheme and/or no host - `urlparse`
    reports `netloc` empty for both), and any scheme outside the
    allowlist - in particular Kodi's own control/local schemes
    (`plugin:`, `script:`, `special:`, `file:`) that resolve to addon
    invocations or local-filesystem paths, not media, if handed to
    `xbmc.Player()`/`ListItem` unchecked.

    The raised message never embeds `url` itself (or any userinfo/path/
    query/fragment out of it) - a Stream dict is untrusted addon data,
    and this error's text reaches kodi.log (`lib.ui.player` logs `%r`
    of the exception) and a user-visible notification, neither of
    which should ever leak a credential/token/path a malicious or
    misconfigured addon embedded in a rejected url. Only the bare
    scheme (never sensitive on its own) is included when that's what
    failed; anything else (missing/malformed) gets a generic message.
    """
    try:
        parsed = urlparse(url) if isinstance(url, str) and url else None
    except ValueError:
        parsed = None
    if parsed is None or not parsed.netloc:
        raise UnsupportedStreamError('Stream url is empty, relative, or malformed')
    scheme = parsed.scheme.lower()
    if scheme not in _DIRECT_URL_SCHEMES:
        raise UnsupportedStreamError('Stream url scheme %r is not an allowed direct-playback scheme' % (scheme,))
    return url


class ServerError(Exception):
    """Raised when a rivulet-engine engine/stats request fails.

    Mirrors AddonError/ApiError in this package: network failures and
    malformed JSON both surface as this one type so callers (e.g. the
    playback pre-buffer poller) can catch a single exception and fall
    back to "proceed without buffering" rather than bricking playback.
    """


class RangeNotSatisfiableError(ServerError):
    """HTTP 416 from a ranged read: the requested range starts at/after
    EOF. Terminal for a range loop (the file is already fully read)."""


class UnsupportedStreamError(ServerError):
    """Raised by `resolve_stream()` for a Stream source kind stremio-core
    itself recognizes but that can never be handed to Kodi's player:
    `externalUrl` (`StreamSource::External`, stream.rs:826-835 - meant
    to be opened by a native app or deep link, e.g. a torrent client or
    a platform store listing) and `playerFrameUrl`
    (`StreamSource::PlayerFrame`, stream.rs:818-821 - an embeddable
    IFRAME player, not a media URL at all); and, since a Stream dict is
    untrusted addon data, an empty/relative/malformed `url` field or one
    outside `_DIRECT_URL_SCHEMES` (a Kodi control/local scheme such as
    `plugin:`/`script:`/`special:`/`file:` would let a rogue addon run
    addon code or read local files via `xbmc.Player()`/`ListItem`
    instead of merely failing to play a video). Distinct from
    `resolve_stream()` returning None (which means "unrecognized
    source" or "missing data needed to build a URL") so a caller can
    show a precise, honest message instead of the generic "no playable
    stream found" one.
    """


class ServerClient:
    """Talks to a local rivulet-engine instance (default http://127.0.0.1:11470).

    One `requests.Session()` per client instance (stored as `.session`, not
    private, so callers/tests can substitute it directly - mirrors
    AddonClient in addons.py). Session creation is gated behind the same
    `requests is None` check the rest of this module uses for the optional
    dependency, so constructing a client without `requests` installed still
    doesn't crash; `.session` just stays `None`, which is_available() (and
    every other method below) already treats as "unavailable"/raises on.
    """

    def __init__(self, base_url):
        self.base_url = (base_url or '').rstrip('/')
        self.session = requests.Session() if _ensure_requests() is not None else None

    def is_available(self):
        """Probe the server: GET /heartbeat, falling back to /settings.

        A responder only counts if its body looks like rivulet-engine
        (`{"success": true}` for /heartbeat, an object with `values` for
        /settings), so an unrelated service squatting the port is not
        adopted. Short timeout; returns False on ANY error rather than
        raising.
        """
        if requests is None:
            return False
        for path, check in (('/heartbeat', _is_heartbeat_body), ('/settings', _is_settings_body)):
            try:
                resp = self.session.get(self.base_url + path, timeout=2)
                if not resp.ok:
                    continue
                if check(resp.json()):
                    return True
            except (requests.RequestException, ValueError):
                continue
        return False

    def remove_engine(self, info_hash, timeout=2):
        """Best-effort `GET /{ih}/remove` (drop the torrent engine at
        playback end). Short timeout; returns True on success, never raises."""
        if requests is None or self.session is None:
            return False
        normalized = normalize_info_hash(info_hash) or str(info_hash).lower()
        try:
            resp = self.session.get('%s/%s/remove' % (self.base_url, normalized), timeout=timeout)
            return bool(resp.ok)
        except Exception:  # noqa: BLE001 - best-effort cleanup
            return False

    @staticmethod
    def _tr_query(trackers):
        """`?tr=...&tr=...` for `trackers` (normalized and encoded the way
        Rust's `url::Url::query_pairs_mut()` does - see `torrent_url`), or
        '' when there are none."""
        normalized = normalize_trackers(trackers)
        if not normalized:
            return ''
        return '?' + urlencode([('tr', tracker) for tracker in normalized])

    def torrent_url(self, info_hash, file_idx, announce=None):
        """Build `{base}/{infoHash}/{fileIdx}[?tr=...&tr=...]`, or None if
        `info_hash` can't be normalized to a usable hash.

        `info_hash` is normalized via `normalize_info_hash()` - accepting
        either the 40-char hex form or a magnet's 32-char Base32 form,
        always lowercased hex on output (stremio-core's `hex::encode` is
        always lowercase). `announce` is normalized via
        `normalize_trackers()` (percent-decoded, deduped) before being
        encoded the way Rust's `url::Url::query_pairs_mut()` encodes
        query params - application/x-www-form-urlencoded (space -> '+'),
        which is NOT the same percent-encoding scheme
        addons.encode_extra() uses for extra props.
        """
        normalized_hash = normalize_info_hash(info_hash)
        if normalized_hash is None:
            return None
        return '%s/%s/%s%s' % (self.base_url, normalized_hash, _clean_file_idx(file_idx), self._tr_query(announce))

    def _magnet_to_torrent_url(self, magnet):
        """Parse `magnet:?dn=...&xt=urn:btih:<hash>&tr=...` (the exact shape
        stremio-core's build_magnet_uri produces, stream.rs:1036-1071) back
        into a torrent_url(), or None if it has no usable btih info hash.
        """
        try:
            query = parse_qs(urlparse(magnet).query)
        except ValueError:
            return None
        info_hash = next(
            (xt.split(':', 2)[2] for xt in query.get('xt', []) if xt.lower().startswith('urn:btih:')),
            None,
        )
        if not info_hash:
            return None
        return self.torrent_url(info_hash, UNKNOWN_FILE_IDX, query.get('tr', []))

    def create_engine(self, info_hash, timeout=100, trackers=None):
        """`GET {base}/{infoHash}/create` (or, with `trackers`, `POST` the
        same path with a `peerSearch` body) - start/attach the torrent engine.

        Per rivulet-engine's handleCreate (internal/api/api.go,
        docs/swagger.yaml `/{infoHash}/create`), the server calls
        EnsureEngine + Ready() with a 90s timeout blocking until torrent
        metadata is available, then returns `types.Stats` including
        `guessedFileIdx` (set when the server picked a best file).
        Defaults to a 100s client timeout (above the server's 90s Ready()
        budget); callers polling in a cancellable UI loop pass a short
        timeout instead so a slow /create can't freeze the loop between
        cancel checks (each timeout just re-polls the same warming engine).

        `trackers` (a raw announce/sources list, normalized by
        `normalize_trackers()`) makes the request the way stremio-core's
        CreateTorrentRequest does: `POST {"peerSearch": {"min": 40, "max":
        200, "sources": ["dht:<hash>", "tracker:<url>", ...]}}`
        (streaming_server/request.rs, statistics.rs `PeerSearch::new`).
        handleCreate has merged `peerSearch.sources` trackers into the
        engine since v0.1.0 - the GET form's query string is NOT read, so
        this is the only way to hand a stream's own trackers to the server
        during the metadata wait on every released server version. The
        merge also applies to an engine that already exists, so repeating
        it on every poll is harmless. Without trackers it stays the plain
        body-less GET.
        """
        if requests is None:
            raise ServerError('the "requests" package is required for ServerClient')
        normalized_hash = str(info_hash).lower()
        url = '%s/%s/create' % (self.base_url, normalized_hash)
        sources = ['tracker:%s' % tracker for tracker in normalize_trackers(trackers)]
        method = 'POST' if sources else 'GET'
        try:
            if sources:
                body = {'peerSearch': {'min': 40, 'max': 200, 'sources': ['dht:%s' % normalized_hash] + sources}}
                resp = self.session.post(url, json=body, timeout=timeout)
            else:
                resp = self.session.get(url, timeout=timeout)
            resp.raise_for_status()
        except requests.RequestException as exc:
            raise ServerError('%s %s failed: %s' % (method, _redact_error_url(self.base_url, url), _request_error_category(exc)))
        try:
            return resp.json()
        except ValueError as exc:
            raise ServerError('%s %s returned invalid JSON: %s' % (method, _redact_error_url(self.base_url, url), exc))

    def iter_front(self, info_hash, file_idx, want_bytes, chunk_size=16384, timeout=60, start_byte=0,
                   trackers=None):
        """Stream the FRONT of a torrent file from `start_byte`, yielding
        each chunk's length as it arrives - the pre-buffer readiness probe.

        Issues `GET {base}/{infoHash}/{fileIdx}` with a `Range:
        bytes=<start_byte>-(want_bytes-1)` header (the same request shape
        Kodi's own player makes, offset by `start_byte`), streamed rather
        than buffered whole. A connection that closes after delivering
        SOME bytes (IncompleteRead / ChunkedEncodingError - the normal
        shape of a live, poorly-seeded Range read) is treated as a non-
        fatal end of this attempt, since partial front data is still
        meaningful; the caller re-issues a fresh request to keep trying.
        Only a request that fails with NO bytes received raises
        `ServerError`, matching this file's other methods.

        `start_byte` defaults to 0 (the original front-of-file probe).
        Callers retrying after a stall/timeout pass the highest byte
        already received instead, so the retry resumes with `Range:
        bytes=<got>-<want_bytes-1>` rather than re-requesting (and
        re-waiting on) bytes already obtained - see
        `lib.ui.player._prebuffer_torrent`'s buffering loop, which tracks
        cumulative bytes across attempts for exactly this.

        `trackers` (raw announce/sources list, see `normalize_trackers()`)
        is appended as `tr=` params, exactly like the stream URL handed to
        Kodi later. The pre-buffer reads are the first requests that name
        this torrent when its metadata is already cached, so without them
        the engine would only learn the stream's own trackers once the
        player opens the final URL.

        Reading the failure modes: rivulet-engine withholds the 206
        headers until the first body byte exists, so `ReadTimeout` here
        means "the swarm has not delivered the first piece yet" (a cold
        torrent - normal for its first few attempts), not a dead server.
        `requests` also reports urllib3's `ReadTimeoutError` raised while
        reading the BODY as a plain `ConnectionError`, so "failed
        mid-stream: ConnectionError" is the same stall after the headers
        arrived (silence for the whole read timeout), not a reset.

        `chunk_size` defaults small (16 KiB), NOT large: `requests`'
        `iter_content()` does one `raw.read(chunk_size)` per chunk, and if
        the connection closes before a FULL chunk_size of bytes has
        arrived, `http.client` raises `IncompleteRead` for that WHOLE
        chunk before yielding anything - losing every byte read so far in
        it. Live-verified against a real mid-stream close: a 1 MiB
        chunk_size lost an entire ~1 MB of genuinely-received front data
        (reported as 0 bytes obtained) when the connection closed 8 KB
        short of that chunk boundary; shrinking to 16 KiB reduces a worst-
        case loss to a single small tail fragment instead of the whole
        read.
        """
        if requests is None:
            raise ServerError('the "requests" package is required for ServerClient')
        url = '%s/%s/%s%s' % (self.base_url, str(info_hash).lower(), _clean_file_idx(file_idx), self._tr_query(trackers))
        headers = {'Range': 'bytes=%d-%d' % (start_byte, want_bytes - 1)}
        resp = None
        try:
            resp = self.session.get(url, headers=headers, stream=True, timeout=timeout)
            resp.raise_for_status()
        except requests.RequestException as exc:
            # stream=True keeps the connection open on an HTTP error
            # status; the iteration `finally` below is not reached yet.
            _close_quietly(resp)
            status = getattr(getattr(exc, 'response', None), 'status_code', None)
            message = 'GET %s failed: %s' % (_redact_error_url(self.base_url, url), _request_error_category(exc))
            if status == 416:
                raise RangeNotSatisfiableError(message)
            raise ServerError(message)
        got = 0
        try:
            for chunk in resp.iter_content(chunk_size=chunk_size):
                if not chunk:
                    continue
                got += len(chunk)
                yield len(chunk)
                if start_byte + got >= want_bytes:
                    break
        except requests.RequestException as exc:
            if got == 0:
                raise ServerError('GET %s failed mid-stream: %s' % (_redact_error_url(self.base_url, url), _request_error_category(exc)))
            return
        finally:
            _close_quietly(resp)

    def _lz_query_url(self, path, body, keyed=False):
        """GET `{base}/{path}?lz=<payload>` - the shape shared by every
        rivulet-engine endpoint that takes a JSON body via a query
        string instead of a POST body: archive/nzb `.../create` and the
        ftp(s) proxy `/ftp/{filename}`. `<payload>` is
        `compress_to_encoded_uri_component()` of the compact-JSON
        `body`, exactly how stream.rs builds every one of these
        (`serde_json::to_string(&payload)` then `lz_str::
        compress_to_encoded_uri_component(&stream_data)`).

        With `keyed=True` (archive/nzb create only) a deterministic
        session key is appended to `path` as `{path}/{key}`, where `key`
        is the lowercase hex sha256 of that exact compact-JSON body
        truncated to 32 chars (path-safe, no escaping needed). Since
        rivulet-engine v0.21.0 the keyed GET form parses `?lz=` too
        (key = path segment 2), and since v0.23.0 re-requesting the SAME
        key with an equivalent payload reuses the live archive/NZB
        session (download + extraction/assembly kept for ~1 h; local
        archives are rechecked by size+mtime) instead of building a
        fresh one - so Kodi's repeated stat/probe/open and resume after
        stop no longer re-download/re-extract. Same body -> same key;
        any differing field (urls, fileIdx, fileMustInclude, servers...)
        -> a different key. This is an opt-in enhancement: upstream
        stremio-core sends the unkeyed `/{kind}/create`, which the
        server still accepts (and which always builds a fresh session).
        """
        from lib.stremio.lzstring import compress_to_encoded_uri_component
        body_json = json.dumps(body, separators=(',', ':'))
        if keyed:
            key = hashlib.sha256(body_json.encode('utf-8')).hexdigest()[:32]
            path = '%s/%s' % (path, key)
        compressed = compress_to_encoded_uri_component(body_json)
        return '%s/%s?%s' % (self.base_url, path, urlencode({'lz': compressed}))

    def _ftp_create_url(self, url):
        """Rewrite an `ftp://`/`ftps://` url into the proxied
        `{base}/ftp/{filename}?lz=<payload>` form rivulet-engine
        actually fetches - Kodi (like most HTTP clients) can't open an
        `ftp://` URL directly (`Stream::ftp_url_handler`, stream.rs:
        186-214). `filename` is the url's last path segment
        (`Stream::ftp_filename`, stream.rs:169-176); returns None if
        there isn't one to use (mirrors upstream's
        `EnvError::Other("Ftp(s) filepath is missing in the url")`).
        """
        filename = _ftp_filename(url)
        if not filename:
            return None
        return self._lz_query_url('ftp/%s' % quote(filename, safe=''), {'ftpUrl': url})

    def _archive_create_url(self, kind, raw_urls, file_idx=None, file_must_include=None):
        """Build `{base}/{kind}/create/{key}?lz=<payload>` for an archive
        stream source (`kind` one of 'rar'/'zip'/'7zip'/'tgz'/'tar' -
        stream.rs's Rar/Zip/Zip7/Tgz/Tar `StreamSource::convert()`
        branches, stream.rs:240-403, identical but for the path
        segment).

        `raw_urls` is the Stream protocol's own wire shape for e.g.
        `rarUrls` - a list of `[url]`/`[url, bytes]` pairs
        (`ArchiveUrlShort`, stream.rs:885-899), passed straight through
        rather than converted to an `{"url":..., "bytes":...}` object:
        stream.rs's own doctest for `ArchiveUrl`'s `Serialize` impl
        (stream.rs:838-852) proves the OUTGOING `/…/create` request
        re-serializes each entry back to that same array form, since
        `ArchiveStreamBody.urls: Vec<ArchiveUrl>` and `ArchiveUrl`
        always (de)serializes via `ArchiveUrlShort` in both directions
        (`#[serde(from = ..., into = ...)]`).

        A nested `ftp://`/`ftps://` member url is itself rewritten
        through `/ftp/{filename}` first (`archive_urls_with_ftp_proxy`,
        stream.rs:216-230) - its `bytes` size (if any) is kept as given,
        only the url changes. Returns None if there are no usable
        entries left (mirrors upstream's `if urls.is_empty() { return
        Err(...) }`) or a nested ftp url can't be proxied (no filename
        to build `/ftp/{filename}` from).
        """
        entries = []
        if not isinstance(raw_urls, list):
            raw_urls = []
        for raw in raw_urls[:_MAX_ARCHIVE_URL_ENTRIES]:
            if not raw or not isinstance(raw, (list, tuple)) or not raw[0] or not isinstance(raw[0], str):
                continue
            url = raw[0]
            num_bytes = raw[1] if len(raw) > 1 else None
            if _is_ftp_url(url):
                url = self._ftp_create_url(url)
                if url is None:
                    return None
            entries.append([url] if num_bytes is None else [url, num_bytes])
        if not entries:
            return None

        body = {'urls': entries}
        if file_idx is not None:
            body['fileIdx'] = _clean_file_idx(file_idx)
        if file_must_include:
            body['fileMustInclude'] = list(file_must_include)
        return self._lz_query_url('%s/create' % kind, body, keyed=True)

    def _resolve_nzb_stream(self, stream):
        """Build `{base}/nzb/create/{key}?lz=<payload>` for an Nzb stream
        source (`StreamSource::Nzb`, stream.rs:793-804 - `convert()`
        branch stream.rs:404-437). Supports both the single-url
        `nzbUrl` field and the newer multi-url `nzbUrls` array (upstream
        cb2d5d0c, 2026-03-10); either or both may be present. `servers`
        (Usenet server URLs) are required - an Nzb stream with none can
        never be fetched, mirroring upstream's `if servers.is_empty() {
        return Err(...) }` - and, like every url here, are individually
        proxied through `/ftp/{filename}` first if they carry an
        `ftp://`/`ftps://` scheme.
        """
        servers = []
        raw_servers = stream.get('servers')
        for server_url in raw_servers if isinstance(raw_servers, list) else ():
            if not isinstance(server_url, str) or not server_url:
                continue
            if _is_ftp_url(server_url):
                server_url = self._ftp_create_url(server_url)
                if server_url is None:
                    return None
            servers.append(server_url)
        if not servers:
            return None

        body = {'servers': servers}

        single_url = stream.get('nzbUrl')
        if isinstance(single_url, str) and single_url:
            if _is_ftp_url(single_url):
                single_url = self._ftp_create_url(single_url)
                if single_url is None:
                    return None
            body['nzbUrl'] = single_url

        multi_urls = []
        raw_nzb_urls = stream.get('nzbUrls')
        for nzb_url in (raw_nzb_urls if isinstance(raw_nzb_urls, list) else ())[:_MAX_ARCHIVE_URL_ENTRIES]:
            if not isinstance(nzb_url, str) or not nzb_url:
                continue
            if _is_ftp_url(nzb_url):
                nzb_url = self._ftp_create_url(nzb_url)
                if nzb_url is None:
                    return None
            multi_urls.append(nzb_url)
        if multi_urls:
            body['nzbUrls'] = multi_urls

        return self._lz_query_url('nzb/create', body, keyed=True)

    def resolve_stream(self, stream):
        """Resolve a Stream protocol dict to a playable URL, None, or
        raise `UnsupportedStreamError`.

        - `url`: validated by `_validate_direct_url()` (`_DIRECT_URL_SCHEMES`)
          and returned as-is when allowed, else raises
          `UnsupportedStreamError`; a `magnet:` url is converted via
          _magnet_to_torrent_url() when it carries a parseable info hash,
          else None (playing a bare magnet needs a torrent client, which
          the addon doesn't embed); a bare `ftp://`/`ftps://` url is
          proxied via `_ftp_create_url()`.
        - `infoHash` (+ `fileIdx`, `announce`/`sources`): -> torrent_url(),
          which normalizes `infoHash` (see `normalize_info_hash`) and
          returns None for one that can't be. Missing `fileIdx` defaults
          to UNKNOWN_FILE_IDX (-1), matching stremio-core, NOT 0.
          Trackers come from `announce`, falling back to `sources` when
          absent (`stream_trackers()`) - stremio-core deserializes torrent
          trackers with `#[serde(alias = "sources")]` (stream.rs:812), and
          Torrentio/AIOStreams-style addons ship them under `sources`
          (e.g. "tracker:udp://host:port/announce", "dht:<hash>").
          `normalize_trackers()` strips the "tracker:" wrapper and drops
          "dht:" entries before they become `tr=` params: unlike the
          `peerSearch.sources` body of POST /create (see engine.go
          mergeTrackers / api.go trackersFromSources), the server's
          `tr=` query path did not strip the wrapper up to v0.20.0, so a
          raw "tracker:udp://..." value was dropped as a host-less URL.
        - `ytId`: -> `{base}/yt/{ytId}`.
        - `rarUrls`/`zipUrls`/`7zipUrls`/`tgzUrls`/`tarUrls` (+
          `fileIdx`/`fileMustInclude`): -> `_archive_create_url()`.
        - `nzbUrl`/`nzbUrls` (+ `servers`): -> `_resolve_nzb_stream()`.
        - `externalUrl`/`playerFrameUrl`: raises `UnsupportedStreamError`
          - stremio-core recognizes these StreamSource kinds, but
          neither is a URL Kodi's player can ever open.
        - anything else (no recognized key at all): None, unrecognized.
        """
        if not isinstance(stream, dict):
            return None

        url = stream.get('url')
        if url:
            if is_magnet_url(url):
                return self._magnet_to_torrent_url(url)
            if _is_ftp_url(url):
                return self._ftp_create_url(url)
            return _validate_direct_url(url)

        info_hash = stream.get('infoHash')
        if info_hash:
            file_idx = _clean_file_idx(stream.get('fileIdx'))
            announce = stream_trackers(stream)
            return self.torrent_url(info_hash, file_idx, announce)

        yt_id = stream.get('ytId')
        if yt_id:
            yt_id = str(yt_id)
            if not _YT_ID_RE.match(yt_id):
                return None
            return '%s/yt/%s' % (self.base_url, yt_id)

        for key, kind in _ARCHIVE_KIND_BY_KEY.items():
            if stream.get(key):
                return self._archive_create_url(
                    kind, stream[key], stream.get('fileIdx'), stream.get('fileMustInclude')
                )

        if stream.get('nzbUrl') or stream.get('nzbUrls'):
            return self._resolve_nzb_stream(stream)

        if stream.get('externalUrl') or stream.get('playerFrameUrl'):
            unsupported_key = 'externalUrl' if stream.get('externalUrl') else 'playerFrameUrl'
            raise UnsupportedStreamError(
                'Stremio stream source %r can only be opened in the Stremio app' % unsupported_key
            )

        return None


def is_magnet_url(value):
    """True if `value` is a string with a `magnet:` scheme."""
    return isinstance(value, str) and value.lower().startswith('magnet:')


def magnet_stream(url):
    """`{'infoHash': ..., 'announce': [...]}` for a `magnet:` url with a
    usable btih hash (the shape the torrent pre-buffer consumes), else None."""
    try:
        query = parse_qs(urlparse(url).query)
    except ValueError:
        return None
    info_hash = next(
        (xt.split(':', 2)[2] for xt in query.get('xt', []) if xt.lower().startswith('urn:btih:') and xt.count(':') >= 2),
        None,
    )
    if not info_hash or not normalize_info_hash(info_hash):
        return None
    return {'infoHash': info_hash, 'announce': query.get('tr', [])}


def guess_file_idx(stats):
    """Pick the torrent file index to pre-buffer/poll from a `/create`
    response, tolerating a server-version gap confirmed live against
    rivulet-engine v0.8.5 (Sintel torrent 08ada5a7a618...): that
    build's `/create` response NEVER carries `guessedFileIdx` (only a
    per-file `/{infoHash}/{fileIdx}/stats.json` response does, once a
    concrete index is already being polled) but DOES carry a `files`
    array once metadata resolves (`[{name, path, length, offset}, ...]`).

    Prefers an explicit non-negative int `guessedFileIdx` when present -
    server builds that still emit it up front win outright. Otherwise,
    when `files` is a non-empty list, picks the entry with the largest
    `length` among those with a video extension (ties keep the
    first/lowest index), falling back to the largest of any kind when none
    has one - the same rule as the server's own guess
    (engine.GuessFileIdx; the rivulet-side pick used to be "largest file
    of any kind", which a bundled soundtrack/ISO bigger than the movie
    would win). Returns None when neither is usable.

    Tolerates garbage input throughout rather than raising - this feeds
    a playback pre-buffer poll that must never crash on an unexpected
    server response shape: a non-dict `stats`, a missing/non-list
    `files`, and entries that are not dicts or have a missing/non-numeric
    `length` (treated as length 0) all fall through safely.
    """
    if not isinstance(stats, dict):
        return None

    guessed = stats.get('guessedFileIdx')
    if isinstance(guessed, int) and not isinstance(guessed, bool) and guessed >= 0:
        return guessed

    files = stats.get('files')
    if not isinstance(files, list) or not files:
        return None

    best_idx, best_length = None, -1
    best_video_idx, best_video_length = None, -1
    for idx, entry in enumerate(files):
        length = entry.get('length') if isinstance(entry, dict) else None
        try:
            length = float(length)
        except (TypeError, ValueError):
            length = 0
        if length > best_length:
            best_idx, best_length = idx, length
        if length > best_video_length and _is_video_entry(entry):
            best_video_idx, best_video_length = idx, length
    # Same preference as the server's own guess (engine.GuessFileIdx): the
    # largest VIDEO file, only then the largest file of any kind - a bundled
    # soundtrack/ISO/extras archive bigger than the movie must not win.
    return best_video_idx if best_video_idx is not None else best_idx


def _is_video_entry(entry):
    """True if a `/create` `files[]` entry names a playable video file,
    by the same extension set rivulet-engine's GuessFileIdx uses
    (engine.go `videoExts`)."""
    if not isinstance(entry, dict):
        return False
    name = entry.get('path') or entry.get('name')
    return isinstance(name, str) and name.lower().endswith(_VIDEO_EXTENSIONS)
