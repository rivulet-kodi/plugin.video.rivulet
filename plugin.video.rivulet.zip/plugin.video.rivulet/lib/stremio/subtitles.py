# SPDX-FileCopyrightText: 2026 M0Rf30
# SPDX-License-Identifier: MIT

"""Subtitle discovery for playback (pure Python, no ``xbmc*`` imports).

Queries every installed Stremio addon that declares subtitle support for
the content being played, merges the results, drops duplicates/unusable
entries, and narrows what is left to the user's preferred language so the
player can hand Kodi a list it can safely auto-select from.

OpenSubtitles v3 (bundled in the Store's default addon list) accepts the
usual stream ``extra`` props -- ``filename`` and ``videoSize`` -- to
improve its match. ``videoHash`` is intentionally not computed here: it
requires reading bytes off the resolved media file, which this layer
doesn't have access to.

Upstream's subtitle resource also carries an optional ``fonts`` field
(custom font URLs for styled subtitles, stremio-core commit b1bd9b3f);
it is intentionally dropped here because Kodi's libass renderer cannot
fetch remote fonts, so carrying it through would be dead weight.
"""
from urllib.parse import urlparse

from lib.stremio.addons import addon_supports, iter_manifests
from lib.stremio.fanout import map_bounded

# ISO 639-1 (2-letter) -> ISO 639-2/B (3-letter) codes for the languages
# subtitle addons commonly report. Only used for the loose alias matching
# in filter_subtitles(); an unrecognized code simply won't gain an alias.
_ISO639_1_TO_3 = {
    'af': 'afr', 'am': 'amh', 'ar': 'ara', 'az': 'aze', 'be': 'bel',
    'bg': 'bul', 'bn': 'ben', 'bs': 'bos', 'ca': 'cat', 'cs': 'cze',
    'cy': 'wel', 'da': 'dan', 'de': 'ger', 'el': 'gre', 'en': 'eng',
    'eo': 'epo', 'es': 'spa', 'et': 'est', 'eu': 'baq', 'fa': 'per',
    'fi': 'fin', 'fil': 'fil', 'fr': 'fre', 'ga': 'gle', 'gl': 'glg',
    'gu': 'guj', 'he': 'heb', 'hi': 'hin', 'hr': 'hrv', 'hu': 'hun',
    'hy': 'arm', 'id': 'ind', 'is': 'ice', 'it': 'ita', 'ja': 'jpn',
    'ka': 'geo', 'kk': 'kaz', 'km': 'khm', 'kn': 'kan', 'ko': 'kor',
    'ku': 'kur', 'ky': 'kir', 'lo': 'lao', 'lt': 'lit', 'lv': 'lav',
    'mk': 'mac', 'ml': 'mal', 'mn': 'mon', 'mr': 'mar', 'ms': 'may',
    'mt': 'mlt', 'my': 'bur', 'ne': 'nep', 'nl': 'dut', 'no': 'nor',
    'pa': 'pan', 'pl': 'pol', 'pt': 'por', 'ro': 'rum', 'ru': 'rus',
    'si': 'sin', 'sk': 'slo', 'sl': 'slv', 'sq': 'alb', 'sr': 'srp',
    'sv': 'swe', 'sw': 'swa', 'ta': 'tam', 'te': 'tel', 'th': 'tha',
    'tl': 'tgl', 'tr': 'tur', 'uk': 'ukr', 'ur': 'urd', 'uz': 'uzb',
    'vi': 'vie', 'zh': 'chi',
}

# A handful of languages have distinct ISO 639-2/T (terminological) codes
# that also show up in the wild alongside the /B form above.
_ISO639_1_TO_3_ALT = {
    'cs': 'ces', 'cy': 'cym', 'de': 'deu', 'el': 'ell', 'es': 'spa',
    'eu': 'eus', 'fa': 'fas', 'fr': 'fra', 'hy': 'hye', 'is': 'isl',
    'ka': 'kat', 'mk': 'mkd', 'ms': 'msa', 'my': 'mya', 'nl': 'nld',
    'ro': 'ron', 'sk': 'slk', 'sq': 'sqi', 'zh': 'zho',
}

# Non-ISO codes the OpenSubtitles v3 addon (and the OpenSubtitles API it
# wraps) reports for regional variants, mapped to their base language:
# Brazilian/Mozambican Portuguese, Traditional/Simplified Chinese and the
# Chinese-English bilingual track. Without them a user asking for `pt` or
# `zh` would never see those tracks.
_EXTENSION_CODES = {
    'pob': 'pt', 'pom': 'pt', 'zht': 'zh', 'zhc': 'zh', 'ze': 'zh',
}

_ISO639_3_TO_1 = {three: two for two, three in _ISO639_1_TO_3.items()}
_ISO639_3_TO_1.update({three: two for two, three in _ISO639_1_TO_3_ALT.items()})


def _lang_aliases(code):
    """Return the set of language codes considered equivalent to `code`
    (itself, its ISO 639-1<->639-2 counterparts when known, and the base
    language of a BCP 47 / locale tag such as ``pt-BR`` or ``en_US`` or of
    an OpenSubtitles extension code such as ``pob``), lowercased."""
    code = (code or '').strip().lower()
    if not code:
        return set()
    aliases = {code}
    base = code.replace('_', '-').split('-', 1)[0]
    base = _EXTENSION_CODES.get(base, base)
    aliases.add(base)
    three = _ISO639_1_TO_3.get(base)
    if three:
        aliases.add(three)
    alt = _ISO639_1_TO_3_ALT.get(base)
    if alt:
        aliases.add(alt)
    two = _ISO639_3_TO_1.get(base)
    if two:
        aliases.add(two)
    return aliases


def _sanitize_label(label):
    """Return `label` (the addon's human-readable subtitle name, e.g.
    "English (SDH)" or "Forced") stripped of embedded CR/LF and leading
    /trailing whitespace, or `None` if it doesn't resolve to a non-empty
    string.

    `label` is optional per the upstream resource schema
    (stremio-core commit b1bd9b3f, src/types/resource/subtitles.rs), so
    unlike `lang` (which always defaults to `''`) an absent/blank label
    means the key is omitted from the result entirely rather than kept
    as an empty string.
    """
    if not label:
        return None
    text = str(label).replace('\r', '').replace('\n', '').strip()
    return text or None


#: Cap on concurrent addon HTTP calls `collect_subtitles()` opens at once -
#: mirrors `lib.ui.views._MAX_ADDON_WORKERS`'s bounded-pool convention as
#: its own local constant (this module deliberately carries no
#: `lib.ui`/`xbmc*` imports, so it can't just import that one - see the
#: module docstring). Each `AddonClient.subtitles()` call still carries
#: its own 15s timeout (`AddonClient`'s default, addons.py); this runs on
#: every playback start, before `xbmc.Player().play()`, so querying
#: subtitle addons one at a time paid that timeout N times over first -
#: measured +0.4-1.5s per play typical, +15s per addon worst case.
#: Fanning out turns that sum() into a max().
_MAX_SUBTITLE_ADDON_WORKERS = 8

#: Subtitle addons are untrusted network data (same trust boundary as a
#: Stream's `url`, see `lib.stremio.server._DIRECT_URL_SCHEMES` and
#: `_validate_direct_url()`, which this mirrors minimally rather than
#: importing - `lib.ui.player` hands every kept `url` straight to
#: `ListItem.setSubtitles()`, so a non-http(s) scheme (or a non-str
#: value, which would raise on the `url in seen_urls` membership test
#: below) must never reach that call.
_SUBTITLE_URL_SCHEMES = frozenset({'http', 'https'})


def _is_usable_subtitle_url(url):
    """Return True if `url` is a str with an allowed subtitle scheme."""
    if not isinstance(url, str) or not url:
        return False
    try:
        return urlparse(url).scheme.lower() in _SUBTITLE_URL_SCHEMES
    except ValueError:  # e.g. 'http://[x/a'
        return False


def _query_addons(client, transport_urls, rtype, rid, extra):
    """Call `client.subtitles()` once per URL in `transport_urls`, fanned
    out across a small bounded thread pool (see
    `_MAX_SUBTITLE_ADDON_WORKERS`) instead of one call at a time, and
    return the raw per-addon results in the SAME ORDER as
    `transport_urls`, regardless of which addon answers first -
    `collect_subtitles()`'s merge below relies on that order for its
    "first occurrence wins" dedup. A per-addon request failure is
    swallowed here (that slot's result is `None`), so one broken addon -
    whichever worker thread happens to hit it - can never sink the
    others.
    """
    def _one(transport_url):
        try:
            return client.subtitles(transport_url, rtype, rid, extra=extra)
        except Exception:  # noqa: BLE001 - one addon's failure must not sink the rest
            return None

    if not transport_urls:
        return []
    if len(transport_urls) == 1:
        return [_one(transport_urls[0])]
    return map_bounded(_one, transport_urls, _MAX_SUBTITLE_ADDON_WORKERS)


def collect_subtitles(client, addons, rtype, rid, extra=None):
    """Query every addon in `addons` (Store descriptors, as returned by
    `Store.get_addons()`) that declares subtitle support for `rtype`/`rid`,
    merge their results, and return a flat list of `{id, lang, url}` dicts,
    each with an optional `label` key (see `_sanitize_label`) when the
    addon supplied a usable one.

    Subtitle-capable addons are queried CONCURRENTLY, not one at a time
    (see `_MAX_SUBTITLE_ADDON_WORKERS`/`_query_addons`) - this runs on
    every playback start, before `xbmc.Player().play()`, so a serial loop
    paid every addon's full request latency in sequence. The merge below
    still walks addons in their original `addons` order, so output order
    and the "first occurrence wins" dedup are unaffected by which addon
    happens to answer first.

    A per-addon request failure (network error, malformed JSON, whatever)
    is swallowed so one broken addon never hides subtitles from the rest.
    Entries without a usable `url` are dropped; duplicate URLs (across or
    within addons) keep only the first occurrence.
    """
    transport_urls = []
    for transport_url, manifest in iter_manifests(addons):
        if transport_url and addon_supports(manifest, 'subtitles', rtype, rid):
            transport_urls.append(transport_url)

    seen_urls = set()
    subs = []
    for raw in _query_addons(client, transport_urls, rtype, rid, extra):
        for item in raw if isinstance(raw, list) else ():
            if not isinstance(item, dict):
                continue
            url = item.get('url')
            if not _is_usable_subtitle_url(url) or url in seen_urls:
                continue
            seen_urls.add(url)
            entry = {
                'id': item.get('id') or url,
                'lang': str(item.get('lang') or ''),
                'url': url,
            }
            label = _sanitize_label(item.get('label'))
            if label is not None:
                entry['label'] = label
            subs.append(entry)
    return subs


def filter_subtitles(subs, preferred_lang):
    """Return only the `subs` entries whose language matches
    `preferred_lang` (case-insensitive, treating 2-letter/3-letter ISO
    639 codes for the same language as equal), preserving order; an
    unusable/empty `preferred_lang` passes everything through unchanged.

    Ordering alone is not enough for the player: `ListItem.setSubtitles()`
    takes bare paths, and Kodi derives an external subtitle's language
    from the filename of that path (`CUtil::GetExternalStreamDetails
    FromFilename` -> `URIUtils::GetFileName`, query string stripped).
    Addon subtitle URLs end in opaque numeric ids, so every attached
    track reaches Kodi with an empty language and Kodi's auto-selection
    picks an arbitrary one. Handing it a single-language list makes that
    arbitrary pick harmless.

    Returns [] when nothing matches - attaching a wrong-language track is
    worse than attaching none, since the file's own embedded tracks do
    carry proper language metadata for Kodi to choose from.
    """
    preferred = _lang_aliases(preferred_lang)
    if not preferred:
        return list(subs or [])
    return [sub for sub in subs or [] if _lang_aliases(sub.get('lang')) & preferred]
